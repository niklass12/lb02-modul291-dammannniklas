### Aufgabe 1: Miniwebshop mit Rabatten erweitern
* Beschreibung: [Demo](https://youtu.be/SSxzjXXw9l8)
* CSS-Framework: [Bootstrap-vue](https://bootstrap-vue.org/docs/components)
* Anpassungen: Suchen Sie nach allen ?? im server/* resp. client/*, um die relevanten 
Programmstellen anzupassen.
