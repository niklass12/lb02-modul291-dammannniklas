<template>
  <div>
    <h2>WARENKORB</h2>
    <table>
      <thead>
      <tr>
        <th class="one">Ticketart</th>
        <th>Anzahl</th>
      </tr>
      </thead>
      <tbody>
      <tr v-for="(product, idx) in cart" :key="idx">
        <td>{{ product.name }}</td>
        <td>{{ product.quantity  }}</td>
      </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
import { mapState } from 'vuex';
export default {
  name: 'Cart',
  computed: mapState(['cart'])
}
</script>

<style lang="scss">

.container-fluid {
  width: 100%;
  padding-right: 15px;
  display: block;
  align-items: center;
  padding-left: 15px;
  margin-right: auto;
  margin-left: auto;
}

.one {
  padding-left: 770px;
  padding-right: 10px;
}
</style>
