<template>
  <div class="container">
    <div class="user-input">
      <button class="button--navi" @click="goHome()">Go to Home</button>
      <button class="button--navi" @click="goBack()">Go Back</button>
      <button class="button--navi" @click="goForward()">Go Forward</button>
    </div>
  </div>
</template>


<script>
export default {
  methods: {
    goHome() {
      this.$router.push('/');
    },
    goBack() {
      this.$router.go(-1);
    }, goForward() {
      this.$router.go(1);
    }
  }
}
</script>

<style lang="scss">

.container {
  max-width: 800px;
  margin: 100px auto;
}


.user-input {
  display: flex;
  align-items: center;
  padding-bottom: 20px;

  input {
    width: 100%;
    padding: 10px 6px;
    margin-right: 10px;
  }
}

// Buttons
button {
  appearance: none;
  padding: 10px;
  margin: 5px;

  font-weight: bold;
  border-radius: 10px;
  border: none;
  white-space: nowrap;

  + button {
    margin-left: 10px;
  }
}

.button--navi {
  display: block;
  margin: 0 auto;
  background: #bc7fd0;
}

</style>
