<template>
  <div class="about">
    <h1>OPENAIR FRAUENFELD </h1>
    <!--
  Vue Directives: Basic Directives (v-text, v-once, v-html, v-bind, v-if, v-show)
  -->
    <div>
      <h2 v-if="true" v-text="text">Wait..</h2>

      <h3 v-if="true" v-html="html">Wait..</h3>
      <h3 v-else-if="true" v-html="html">Wait..</h3>
      <a
          v-if="true"
          :href="link.url"
          :target="link.target"
          :tabindex="link.tabindex"
          v-text="link.title"
      />
    </div>

  </div>
</template>


<script>
export default {
  data() {
    return {
      // v-text
      text: 'Mehr Infos',
      // v-html
      html: 'Das Openair Frauenfeld ist das grösste Open-Air-Musikfestival der Deutschschweiz und das grösste Hip-Hop-Festival Europas. Die Veranstaltung findet seit 1987 statt. Früher war es unter dem Namen Out in the Green Festival ein Rock- und Blues-Festival, das auch einmal in Winterthur stattfand. Seit 2007 läuft das Open Air unter dem Namen Openair Frauenfeld und präsentiert grösstenteils Hip-Hop-Künstler. Zu den Headlinern in den vergangenen Jahren zählt das Who-Is-Who der internationalen Hip-Hop-Szene. Unter anderem traten bereits Eminem, Kanye West, Jay-Z, Drake, Snoop Dogg, 50 Cent, Kendrick Lamar, Pharrell Williams, OutKast, YG, ASAP Rocky und viele mehr am Openair Frauenfeld auf.',
      // v-bind
      link: {
        url: 'https://www.openair-frauenfeld.ch/',
        target: '_blank',
        tabindex: '0',
        title: 'Infos Openair',
      },
    }
  },
}

</script>