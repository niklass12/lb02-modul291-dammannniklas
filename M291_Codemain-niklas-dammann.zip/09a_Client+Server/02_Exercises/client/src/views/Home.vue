<!--demo-01a: Implementing and Adding a Message Feed Page Using Vue Router -->
<template>
  <div>
    <h2>Holen Sie sich jetzt Ihr Ticket!</h2>
    <p v-for="(m, i) in messages" :key="i">
      {{ m }}
    </p>
  </div>
</template>
<script>
export default {
  data() {
    return {
      messages: [
        'Profitiere vom Last Minute Rabatt',
        'Erlebe atemberaubende Acts wie ASAP Rocky, Playboicarti und viele mehr bei uns live vor Ort',
      ]
    }
  }
}

</script>
