<template>
  <div class="container">
    <h2> Tickets erstatten</h2>
    <div style="margin-top: 5rem"/>
    <div class="user-input">
      <input
          placeholder="Tickets"
          v-model="input"
          @keyup.enter="addItem"
          ref="input"
      /><button @click="addItem">Ticket hinzufügen</button>
    </div>

    <ul v-if="shoppingList">
      <li v-for="item in shoppingList" :key="item" class="item">
        <span>{{ item }}</span>
        <button class="button--remove" @click="deleteItem(item)">Entfernen</button>
      </li>
    </ul>
    <!-- Version 2
    <ul v-if="shoppingList">
      <li v-for="(item,index) in shoppingList" :key="index" class="item"
      ><span>{{ item }}</span>
        <button class="button--remove" @click="deleteItem(index)">Remove</button>
      </li>
    </ul>
    -->
    <br />
    <button class="button--delete" @click="deleteItem()">Alles entfernen</button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      input: '',
      shoppingList: [],
    }
  },
  methods: {
    addItem() {
      // Don't allow adding to the list if empty
      if (!this.input) return
      this.shoppingList.push(this.input)
      // Clear the input after adding
      this.input = ''
      // Focus the input element again for quick typing!
      this.$refs.input.focus()
    },
    deleteItem(item) {
      //only for info purposes
      let index = this.shoppingList.indexOf(item);
      console.log(`item: ${item} at index: ${index}`);
      //no parameter provided ..
      if (item == null){
        //.. deleteAll has been pressed
        this.shoppingList = [];
      } else {
        //assign filtered shopping list without deleted item
        this.shoppingList = this.shoppingList.filter(el => el !== item);
      }
    },
    deleteItem_v2(i) {
      if (i == null) {
        this.shoppingList = []
      } else {
        this.shoppingList = this.shoppingList.filter((item,el) => el !== i);
      }
      //Verkürzte Variante von deleteItem(i)
      // this.shoppingList = i
      //     ? this.shoppingList.filter((item, x) => x !== i)
      //     : []
    },
  },
}
</script>

<style lang="scss">
$color-green: #d5b303;
$color-grey: #eecb02;

.container {
  max-width: 1000px;
  margin: 50px auto;
}

.item {
  display: flex;
  justify-content: space-between;
}

// Type
.h2 {
  font-size: 100px;
}

.user-input {
  display: flex;
  align-items: center;
  padding-bottom: 20px;
  input {
    width: 100%;
    padding: 10px 5px;
    margin-right: 10px;
  }
}

.item {
  display: flex;
  align-items: center;
}

// Buttons
button {
  appearance: none;
  padding: 15px;

  font-weight: bold;
  border-radius: 10px;
  border: none;
  background: $color-grey;
  color: #000000;
  white-space: nowrap;

  + button {
    margin-left: 10px;
  }
}

.button--delete {
  display: block;
  margin: 0 auto;
  background: #eecb02;
}

.button--remove {
  background: none;
  color: red;
  font-size: 15px;
  align-self: flex-end;
}

.bg-info {
  background-color: #eecb02 !important;
}

.navbar-nav {
  display: -ms-flexbox;
  display: -webkit-box;
  display: flex;
  -ms-flex-direction: column;
  -webkit-box-orient: vertical;
  -webkit-box-direction: normal;
  flex-direction: column;
  padding-left: 650px;
  padding-right: 650px;
  margin-bottom: 0;
  list-style: none;
  align-items: flex-start;
}

a {
  color: #000000;
  text-decoration: none;
  background-color: transparent;
  padding: 10px;
}

.bg-info {
  background-color: #eecb02 !important;
}

body {
  margin: 0;
  font-family: "Avenir Next Condensed";
  font-size: 1rem;
  font-weight: 500;
  line-height: 20px;
  color: #212529;
  text-align: center;
  background-color: #eeeeee;
}

div {
  display: block;
  align-items: center;
}

ul {
  display: block;
  margin: 0 auto;
  padding: 60px;
  align-items: center;

  > li {
    margin-bottom: 4px;
  }
}
</style>

