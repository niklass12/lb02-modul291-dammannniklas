<template>
  <div>
    <h1>Single Message</h1>
    {{$route.params.content}}
  </div>
</template>

<script>
export default {
  name: "SingleMessage"
}
</script>
