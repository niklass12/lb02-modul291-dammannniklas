module.exports = {
  //presets: ['@vue/app'],
  presets: [
    '@vue/cli-plugin-babel/preset'
  ]
}
